queries = ["" for i in range(0, 17)]

### 0. Report the votes for the normal (i.e, not special) Senate Election in Maryland in 2018.
### Output column order: candidatename, candidatevotes
### Order by candidatename ascending
queries[0] = """
select candidatename, partyname, candidatevotes
from sen_state_returns

where year = 2018 and statecode = 'MD' and specialelections = False

order by candidatename asc;
"""

### 1. Report the number of votes for candidate 'Ben Cardin' across all the senate elections.
### Output Column: year, statecode, specialelections, candidatevotes 
### Order by candidatevotes increasing
queries[1] = """

select year, statecode, specialelections, candidatevotes
from sen_state_returns

where candidatename = 'Ben Cardin'

order by candidatevotes asc;

"""


### 2. Write a query to output the % increase, truncated to whole integer using TRUNC, in the population from 1950 to 2010.
### So for Autauga, the answer would be: 200  (54571-18186)*100/18186 = 200.7 ==> truncated to 200
### There are some counties with 0 population in 1950 -- remove those counties from the answer.
### Output columns: countyname, statecode, percentincrease
### Order output by precentincrease increasing
queries[2] = """

select counties.name, counties.statecode, TRUNC(((counties.population_2010 - counties.population_1950)*100)/counties.population_1950) AS percentincrease
from counties

where counties.population_1950 != 0

order by percentincrease asc;

"""

### 3. Select all the "distinct" party names that senate candidates have been affiliated over all
### the elections. 
### Output column: partyname
### Order output by partyname ascending
queries[3] = """

select DISTINCT partyname
from sen_state_returns

order by partyname asc;

"""

### 4. Write a query to output for each state how many years ago it was admitted to the union, assuming the current year is 2020. 
### So if a state was admitted to the union in 1819, the answer would 201 (2020 - 1819). Ignore the specific dates.
### Output columns: name, admittedduration
### Order by admittedduration decreasing
queries[4] = """

select name, (2020 - EXTRACT(YEAR FROM admitted_to_union)) AS admittedduration
from states

order by admittedduration desc;

"""

### 5. Write a query to find the states where the increase in population from 1900 to 1950 was lower than the increase in population from 2000 to 2010.
### Output Column: name
### Order by: name increasing
queries[5] = """

select name 
from states

where ((population_1950 - population_1900) < (population_2010 - population_2000))

order by name asc;

"""

### 6. Write a query to find all candidates for senate who satisfy one of the following conditions:
###        - the candidate is a 'democrat' and has more than 750000 votes in Alabama.
###        - the candidate is a 'republican' and has more 1,000,000 votes in Maryland.
###        - the candidate is neither a democrat or nor a republican and has more than 500,000 votes (in any state).
### Some candidates appear under multiple party names. Ignore that for now (in other words, if a democrat has 700,000 votes in AL as a 'democrat' and
### also gets 100,000 votes as something else, that candidate should NOT be in the result
### Also: ignore any party names like 'democratic-farmer-labor' etc.
### Output columns: year, statecode, specialelections, candidatename, partyname
queries[6] = """

select year, statecode, specialelections, candidatename, partyname
from sen_state_returns

where ((partyname = 'democrat' AND candidatevotes > 750000 AND statecode = 'AL') OR
        (partyname = 'republican' AND candidatevotes > 1000000 AND statecode = 'MD') OR
        ((NOT (partyname = 'republican' OR partyname = 'democrat')) AND candidatevotes > 500000));

"""


### 7. Write a query to join the tables states and counties to create a list of county names, county population in 2010, state name, the state
### population in 2010
### Output columns: statename, statepopulation, countyname, countypopulation
### Order first by statename, then by countyname, increasing
queries[7] = """

select states.name AS statename, states.population_2010 AS statepopulation, counties.name AS countyname, counties.population_2010 AS countypopulation
from states

inner join counties on (counties.statecode = states.statecode)

order by statename asc, countyname asc;

"""

### 8. Write a query to join the tables states and counties to find the counties that had over
### 50% of the population of the state in 2010
### Output columns: statename, countyname 
### Order by statename, then by countyname, increasing
queries[8] = """

select states.name AS statename, counties.name AS countyname
from states

inner join counties on  (counties.statecode = states.statecode) 

where ( counties.population_2010 > ((states.population_2010 *50)/100) )

order by statename asc, countyname asc;

"""


### 9. The tables were collected from 2 different sources, and there may be some consistency issues across them. 
### Write a query to find all counties (and the corresponding state names) that are present in "pres_county_returns" table, but 
### do not have any corresponding entry in the "counties"
### table (through straightforward string equality -- so 'Autauga' and 'Autauga ' (with an extra space) would NOT be considered a match.
### Each county+state combination should only appear once in the output.
### HINT: Use "not in".
### Output Columns: countyname, statename
### Order by name, statecode ascending
queries[9] = """

select distinct pres_county_returns.countyname AS countyname, states.name as statename
from pres_county_returns 

inner join states on states.statecode = pres_county_returns.statecode

where (countyname) not in (select name from counties)  

order by countyname, statename asc;

"""


### 10. Write a query to join sen_state_returns and sen_elections to find the candidates that received 70% or more of the total vote.
### Output columns: year, statecode, specialelections, candidatename
### Order by percentage of total vote increasing
queries[10] = """

select sen_state_returns.year AS year, 
        sen_state_returns.statecode AS statecode, 
        sen_state_returns.specialelections AS specialelections, 
        sen_state_returns.candidatename AS candidatename           
from sen_state_returns

join sen_elections on (sen_state_returns.year = sen_elections.year AND
        sen_state_returns.statecode = sen_elections.statecode AND 
        sen_state_returns.specialelections = sen_elections.specialelections)

where ( (sen_state_returns.candidatevotes >= ((sen_elections.totalvotes * 70)/100)) AND 
        sen_elections.totalvotes != 0)

order by ((sen_elections.totalvotes/sen_elections.totalvotes)*100) asc;

"""


### 11. For the 2012 presidential elections and for 'Barack Obama', write a
### query to combine pres_county_returns and counties so that, to produce a result
### with the following columns:
###     countyname, statecode, candidatevotes, population_2010
### However, for the counties in pres_county_returns that do not have a match in 
### 'counties' table, we want population_2010 to be set to NULL.
### Use a left (or right) outer join to achive this.
### Output: countyname, statecode, candidatevotes, population_2010
### Order by: countyname, statecode ascending
queries[11] = """

select pres_county_returns.countyname AS countyname, 
        pres_county_returns.statecode AS statecode,
        pres_county_returns.candidatevotes AS candidatevotes, 
        counties.population_2010 AS population_2010
from counties

right outer join pres_county_returns on (counties.name = pres_county_returns.countyname AND
        counties.statecode = pres_county_returns.statecode)

where (pres_county_returns.year = 2012 AND candidatename = 'Barack Obama')

order by pres_county_returns.countyname asc, pres_county_returns.statecode asc;

"""


### 12. SQL "with" clause can be used to simplify queries. It essentially allows
### specifying temporary tables to be used during the rest of the query. See Section
### 3.8.6 (6th Edition) for some examples.
###
### Below we are providing a part of a query that uses "with" to create a
### temporary table where, for 2000 elections, we are finding the maximum of the
### candidate votes for each county. Join this temporary table with the
### 'pres_county_returns' table to find the winner for each county. 
### This is unfortunately the easiest way to do this task.
###
### You don't need to fully understand what the 'temp' query does to do the join
### -- as provided, the query shows you the result of the "temp" table
### Output columns: countyname, statecode, candidatename
### Order by: countyname, statecode, candidatename
queries[12] = """
with temp as (select countyname, statecode, max(candidatevotes) as maxvotes
        from pres_county_returns
        where year = 2000
        group by countyname, statecode)
select pres_county_returns.countyname, pres_county_returns.statecode, pres_county_returns.candidatename from temp

JOIN pres_county_returns on (temp.countyname = pres_county_returns.countyname AND 
        temp.statecode = pres_county_returns.statecode AND
        temp.maxvotes = pres_county_returns.candidatevotes)

order by pres_county_returns.countyname, pres_county_returns.statecode, pres_county_returns.candidatename;

"""


### 13. List the top ten most common names used for counties across the states. 
###
### Output columns: countyname, num
### Order by num, countyname
queries[13] = """

select counties.name AS countyname, count(counties.name) AS num
from counties

group by counties.name

order by num desc, counties.name

limit 10;

"""


### 14. Let's create a table showing the vote differences between 2000 and 2016 for
### the democratic presidential candidates in each county. 
### We ONLY want those states/counties for which we have all the information.
### Output: statecode, countyname, votes2000, votes2016
### Order by: statecode, countyname ascending
queries[14] = """
with for_2000 as (select pres_county_returns.statecode AS statecode,
        pres_county_returns.countyname AS countyname,
        pres_county_returns.candidatevotes AS votes2000
        from pres_county_returns
        where pres_county_returns.year = 2000 AND pres_county_returns.partyname = 'democrat'), 

for_2016 as (select pres_county_returns.statecode AS statecode,
        pres_county_returns.countyname AS countyname,
        pres_county_returns.candidatevotes AS votes2016
        from pres_county_returns
        where pres_county_returns.year = 2016 AND pres_county_returns.partyname = 'democrat')

select for_2000.statecode, for_2000.countyname, for_2000.votes2000, for_2016.votes2016 
from for_2000

join for_2016 on (for_2000.statecode = for_2016.statecode AND
                for_2000.countyname = for_2016.countyname)

order by for_2000.statecode, for_2000.countyname;

"""



### 15. Write a statement to add a new column to the counties table called 'pop_trend' of type 'string'.
queries[15] = """

alter table counties

add column pop_trend varchar;

"""

### 16. The values for the above added column with be empty to begin with. Write an update statement to 
### set it to 'decreased', 'increased somewhat', and 'increased a lot', depending on whether the population decreased,
### increased by less than a factor of 2 (i.e., population_2010 <= 2*population_1950), or increased by a factor of more than 2.
### Use CASE statement to make this easier.
queries[16] = """
Update counties

set pop_trend = 
        (CASE
                When population_2010 >= 2*population_1950
                        Then 'increased a lot'
                When population_2010 < population_1950
                        Then 'decreased'
                When population_2010 > population_1950
                        Then 'increased somewhat'
        END);

"""


