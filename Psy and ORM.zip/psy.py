##Name: Ritika Munshi
##UID: 118345048
#!/usr/bin/python3
import psycopg2
import json
import sys
from types import *

def runPsy(conn, curs, jsonFile):
    with open(jsonFile) as f:
        for line in f:
            data = json.loads(line) ##load the file and return dictionary
            
            try: 
                ##if newcustomer
                x = data["newcustomer"]

                ##Failure check: condition 2: If the customerid for a newcustomer update is already present
                curs.execute("select * from customers where customerid = \'" + x["customerid"]+"\'")
                d = curs.fetchone()

                fli = x["frequentflieron"] #get frequentflieron from newcustomer
                id = x["customerid"] #get customerid from newcustomer
                n = x["name"] #get name from newcustomer
                bd = x["birthdate"] #get birthdate from newcustomer

                ##Failure check: condition 1: if the frequentflieron does not have a match in the airlines table
                curs.execute("select name from airlines where name != \'" + fli +"\'")
                d1 = curs.fetchone()

                ##error handling for both the conditions of Failure checks
                if (d == ""):
                    print("Error424")
                    sys.exit()
                if (d1 == ""):  
                    print("Error424")
                    sys.exit()
                curs.execute("Select airlineid from airlines where " + "airlines.name = "+ " \'"+fli + "\'")
                airid = curs.fetchone()
                #print(airid)
                ##if no error the update the customers table
                sql = "Insert into customers (customerid, name, birthdate, frequentflieron) VALUES ('%s', '%s', to_date('%s','yyyy-mm-dd'), '%s')"% (id, n, bd, airid[0])
               # print(sql)
                curs.execute(sql)
                

            except:     
                ##if flewon          
                y = data["flewon"]

                ##iterate over the customers key that we have for flewon in the JSON file to access the array of values
                for s in y["customers"]:
                    k = s["customerid"] ##get the cutomerid
                
                    ##check if the customerid exist in the customers table
                    curs.execute("Select * from customers where customerid = \'" + k +"\'")
                    d = curs.fetchone()

                    ##if the customerid exist in the customers table
                    if (d != None):
                        ##update the flewon table
                        curs.execute("Insert into flewon (flightid, flightdate,customerid ) VALUES (%s, %s, %s)", (y["flightid"], y["flightdate"], k))
                    ##if the customerid does not exist in the customers table
                    else: 
                        n = s["name"]
                        b = s["birthdate"]
                        f = s["frequentflieron"]
                        
                        ##update customers table first
                        curs.execute("Insert into customers (customerid, name, birthdate, frequentflieron) VALUES (%s, %s, %s, %s)", (k, n, b, f))
                        ##update flewon table now
                        curs.execute("Insert into flewon (flightid, flightdate,customerid ) VALUES (%s, %s, %s)", (y["flightid"], y["flightdate"], k))
##          ...

        conn.commit()
