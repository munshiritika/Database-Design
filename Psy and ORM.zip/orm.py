##Name: Ritika Munshi
##UID: 118345048
from datetime import date
from datetime import datetime
import json

from peewee import *

##database = PostgresqlDatabase('flightsskewed', **{'user': 'vagrant', 'password': 'vagrnat'})
database = PostgresqlDatabase('flightsskewed', **{'host': 'localhost', 'user': 'vagrant', 'password': 'vagrant'})

class UnknownField(object):
    def __init__(self, *_, **__): pass

class BaseModel(Model):
    class Meta:
        database = database

class Airports(BaseModel):
    airportid = CharField(primary_key=True)
    city = CharField(null=True)
    name = CharField(null=True)
    total2011 = IntegerField(null=True)
    total2012 = IntegerField(null=True)

    class Meta:
        table_name = 'airports'

class Airlines(BaseModel):
    airlineid = CharField(primary_key=True)
    hub = ForeignKeyField(column_name='hub', field='airportid', model=Airports, null=True)
    name = CharField(null=True)

    class Meta:
        table_name = 'airlines'

class Customers(BaseModel):
    birthdate = DateField(null=True)
    customerid = CharField(primary_key=True)
    frequentflieron = ForeignKeyField(column_name='frequentflieron', field='airlineid', model=Airlines, null=True)
    name = CharField(null=True)

    class Meta:
        table_name = 'customers'

class Flights(BaseModel):
    airlineid = ForeignKeyField(column_name='airlineid', field='airlineid', model=Airlines, null=True)
    dest = ForeignKeyField(column_name='dest', field='airportid', model=Airports, null=True)
    flightid = CharField(primary_key=True)
    local_arrival_time = TimeField(null=True)
    local_departing_time = TimeField(null=True)
    source = ForeignKeyField(backref='airports_source_set', column_name='source', field='airportid', model=Airports, null=True)

    class Meta:
        table_name = 'flights'

class Flewon(BaseModel):
    customerid = ForeignKeyField(column_name='customerid', field='customerid', model=Customers, null=True)
    flightdate = DateField(null=True)
    flightid = ForeignKeyField(column_name='flightid', field='flightid', model=Flights, null=True)

    class Meta:
        table_name = 'flewon'

class Numberofflightstaken(BaseModel):
    customerid = CharField(null=True)
    customername = CharField(null=True)
    numflights = IntegerField(null=True)

    class Meta:
        table_name = 'numberofflightstaken'
        primary_key = False

def runORM(jsonFile):
    '''
        Customers.delete().where(Customers.name == 'bob').execute()
        Airports.delete().where(Airports.airportid == 'PET').execute()
        
        bob = Customers(name="bob", customerid='cust1010', birthdate='1960-01-15', frequentflieron='SW')
        bob.save(force_insert=True)
    
        bwi = Airports(airportid='PET', city='Takoma', name='Pete', total2011=2, total2012=4)
        bwi.save(force_insert=True)
    
        for port in Airports.select().order_by(Airports.name):
            print (port.name)
    '''

    with open(jsonFile) as f:
        ss = "Delete from numberofflightstaken" ##delete data from numberofflightstaken

        f1 = (Flewon.select(Flewon.customerid, (fn.COUNT(Flewon.customerid)).alias('coun'), Customers.name).join(Customers, attr='customer').where(Flewon.customerid == Customers.customerid).group_by(Flewon.customerid, Customers.name))

        for val in f1:
            v = Numberofflightstaken(customerid=val.customerid, customername = val.customer.name, numflights = val.coun)
            v.save(force_insert=True)

        for line in f:
            data = json.loads(line) ##load the file and return dictionary
            
            try: 
                ##if newcustomer
                x = data["newcustomer"]

                ##Failure check: condition 2: If the customerid for a newcustomer update is already present
                d = (Customers.select(Customers.customerid, Customers.name, Customers.birthdate, Customers.frequentflieron).where(Customers.customerid == x["customerid"])).execute()  
                #d.save(force_insert=True)              

                fli = x["frequentflieron"] #get frequentflieron from newcustomer
                id = x["customerid"] #get customerid from newcustomer
                n = x["name"] #get name from newcustomer
                bd = x["birthdate"] #get birthdate from newcustomer

                ##Failure check: condition 1: if the frequentflieron does not have a match in the airlines table
                d1 = (Airlines.select(Airlines.name).where(Airlines.name != fli)).execute()
                #d1.save(force_insert=True)

                ##error handling for both the conditions of Failure checks
                if (d == ""):
                    print("Error424")
                    sys.exit()
                if (d1 == ""):  
                    print("Error424")
                    sys.exit()

                airid = (Airlines.select(Airlines.airlineid).where(Airlines.name == fli)).execute()
                
                ##if no error the update the customers table
                cust = Customers(birthdate=bd, customerid=x["customerid"], frequentflieron=airid[0], name=n)
                cust.save(force_insert=True)

                ##updating the numberofflightstaken
                Numberofflightstaken.update(numflights = Numberofflightstaken.numflights+1).where(Numberofflightstaken.customerid == Customers.customerid)
                

            except:     
                ##if flewon          
                y = data["flewon"]

                ##iterate over the customers key that we have for flewon in the JSON file to access the array of values
                for s in y["customers"]:
                    k = s["customerid"] ##get the cutomerid
                
                    ##check if the customerid exist in the customers table
                    d = Customers.select().where(Customers.customerid == k).count()
                    #d.save(force_insert=True)
                    #print(d)
                    ##if the customerid exist in the customers table
                    if (d != 0):
                        ##update the flewon table
                        fle = Flewon(customerid=k, flightdate=y["flightdate"], flightid=y["flightid"])
                        fle.save(force_insert=True)

                    ##if the customerid does not exist in the customers table
                    else: 
                        n = s["name"]
                        b = s["birthdate"]
                        f = s["frequentflieron"]
                        
                        ##update customers table first
                        cust = Customers(birthdate=b, customerid=k, frequentflieron=f, name=n)
                        cust.save(force_insert=True)

                        ##update flewon table now
                        f1 = Flewon(customerid=k, flightdate=y["flightdate"], flightid=y["flightid"])
                        f1.save(force_insert=True)

                        ##updating the numberofflightstaken
                        Numberofflightstaken.update(numflights = Numberofflightstaken.numflights+1).where(Numberofflightstaken.customerid == Customers.customerid)
                        



