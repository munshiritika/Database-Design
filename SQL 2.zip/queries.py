queries = ["" for i in range(0, 19)]

### 0. Report the votes for the normal (i.e, not special) Senate Election in Maryland in 2018.
### Output column order: candidatename, candidatevotes
### Order by candidatename ascending
queries[0] = """

select sen_state_returns.candidatename AS candidatename, sen_state_returns.partyname AS partyname, sen_state_returns.candidatevotes AS candidatevotes
from sen_state_returns

where sen_state_returns.specialelections = FALSE AND sen_state_returns.statecode = 'MD' AND sen_state_returns.year = 2018

order by sen_state_returns.candidatename asc;

"""

### 1. Write a query to find the maximum, minimum, and average population in 2010 across all states.
### The result will be a single row.
### Truncate the avg population to a whole number using trunc
### Output Columns: max_population, min_population, avg_population
queries[1] = """

select max(population_2010) AS max_population,
	min(population_2010) AS min_population,
	TRUNC(avg(population_2010)) AS avg_population
from states;

"""

### 2. Write a query to find the candidate with the maximum votes in the 2008 MI Senate Election. 
### Output Column: candidatename
### Order by: candidatename
queries[2] = """

with maxvotes as (select MAX(candidatevotes) AS candidatevotes from sen_state_returns where year = 2008 AND statecode = 'MI')

select candidatename 
from sen_state_returns,maxvotes

where sen_state_returns.candidatevotes = maxvotes.candidatevotes

order by candidatename;

"""

### 3. Write a query to find the number of candidates who are listed in the sen_state_returns table for each senate election held in 2018. 
### Note that there may be two elections in some states, and there should be two tuples in the output for that state.
### 'NA' or '' (empty) should be treated as candidates. 
### Output columns: statecode, specialelections, numcandidates
### Order by: statecode, specialelections
queries[3] = """

select statecode, specialelections, COUNT(sen_state_returns.candidatename) AS numcandidates
from sen_state_returns

where year = 2018

group by statecode, specialelections

order by statecode, specialelections;

"""

### 4. Write a query to find, for the 2008 elections, the number of counties where Barack Obama received strictly more votes 
### than John McCain.
### This will require you to do a self-join, i.e., join pres_county_returns with itself.
### Output columns: num_counties
queries[4] = """

with barak as (select countyname, statecode, candidatevotes 
 	from pres_county_returns 
	where candidatename = 'Barack Obama' AND year = 2008),

john as (select countyname, statecode, candidatevotes 
	from pres_county_returns 
	where candidatename = 'John McCain' AND year = 2008)

select COUNT(barak.countyname) AS num_counties
from barak
join john on (barak.countyname = john.countyname AND	
				barak.statecode = john.statecode)
where barak.candidatevotes > john.candidatevotes AND barak.statecode = john.statecode;
"""


### 5. Write a query to find the names of the states with at least 100 counties in the 'counties' table.
### Use HAVING clause for this purpose.
### Output columns: statename, num_counties
### Order by: statename
queries[5] = """

with state as (select name AS statename, statecode from states),
county as (select name, statecode from counties)

select statename, COUNT(county.name) AS num_counties
from state

join county on state.statecode = county.statecode

GROUP BY state.statename

HAVING (COUNT(county.name) >= 100)

order by statename;

"""

### 6. Write a query to construct a table:
###     (statecode, total_votes_2008, total_votes_2012)
### to count the total number of votes by state for Barack Obama in the two elections.
###
### Use the ability to "sum" an expression (e.g., the following query returns the number of counties in 'AR')
### select sum(case when statecode = 'AR' then 1 else 0 end) from counties;
###
### Order by: statecode
queries[6] = """

with v2008 as (select statecode, SUM(candidatevotes) AS total_votes_2008
				from pres_county_returns 
				where year = 2008 AND candidatename = 'Barack Obama'
				group by statecode),

v2012 as (select statecode, SUM(candidatevotes) AS total_votes_2012
			from pres_county_returns 
			where year = 2012 AND candidatename = 'Barack Obama'
			group by statecode)

select v2008.statecode AS statecode, 
	total_votes_2008, 
	total_votes_2012
from v2008

join v2012 on v2008.statecode = v2012.statecode


order by statecode;

"""

### 7. Create a table to list the disparity between the populations listed in 'states' table and those listed in 'counties' table for 1950 and 2010.
### Result should be: 
###        (statename, disparity_1950, disparity_2010)
### So disparity_1950 = state population 1950 - sum of population_1950 for the counties in that state
### Use HAVING to only output those states where there is some disparity (i.e., where at least one of the two is non-zero)
### Order by statename
queries[7] = """

with state as (select states.name AS statename, statecode,states.population_1950 AS pop1950, states.population_2010 AS pop2010 
				from states
				group by statecode),

county as (select statecode, SUM(counties.population_1950) AS pop1950s, SUM(counties.population_2010) AS pop2010s 
				from counties
				group by statecode)

select statename, (pop1950-pop1950s) AS disparity_1950, (pop2010-pop2010s) AS disparity_2010
from state

join county on state.statecode = county.statecode

where (pop1950-pop1950s != 0 OR pop2010-pop2010s != 0)

order by statename;

"""

### 8. Use 'EXISTS' or 'NOT EXISTS' to find the states where no counties have population in 2010 above 500000 (500 thousand).
### Output columns: statename
### Order by statename
###exist(true) AND not exist(false)
queries[8] = """

select states.name AS statename
from states 

where NOT EXISTS
(select name 
	from counties 
	where population_2010 > 500000 AND states.statecode = counties.statecode)

order by states.name;

"""

### 9. List all counties and their basic information that have a unique name across all states. 
### Use scalar subqueries to simplify the query.
### Output columns: all attributes of counties (name, statecode, population_1950, population_2010)
### Order by name, statecode
queries[9] = """

select name, statecode, population_1950, population_2010
from counties d

where (name NOT IN (select name from counties c where d.name = c.name AND c.statecode != d.statecode))

order by d.name, d.statecode;

"""

### 10. Identify counties that witnessed a population decline between 1950 - 2010 despite belonging to states that witnessed a population growth in the same period. 
### Ouput columns: name, statecode, population_decline
### Order by: population_decline descending.
### Possible solution:
###100000-90000=100000 
queries[10] = """

with county as (select name, statecode, (population_1950 - population_2010) AS population_decline from counties),
state as (select statecode, (population_2010 - population_1950) AS population_growth from states)

select name, county.statecode, population_decline
from county

join state on county.statecode = state.statecode

where (county.statecode = state.statecode AND 
	population_growth > 0 AND population_decline > 0)

order by population_decline desc;

"""

### 11. Use Set Intersection to find the counties that Barack Obama lost in 2008, but won in 2012.
### We have created a temporary table using WITH that you can use (or not).
###
### Output columns: countyname, statecode
### Order by countyname, statecode
queries[11] = """

with v2008 as (select pres.countyname, pres.statecode
				from pres_county_returns pres
				where pres.year = 2008 AND pres.candidatename = 'Barack Obama' AND 
				candidatevotes < (select MAX(candidatevotes) 
									from pres_county_returns coun
									where pres.countyname = coun.countyname AND pres.statecode = coun.statecode AND coun.year = 2008)),

v2012 as (select pres.countyname, pres.statecode
				from pres_county_returns pres
				where pres.year = 2012 AND pres.candidatename = 'Barack Obama' AND 
				candidatevotes = (select MAX(candidatevotes) 
									from pres_county_returns coun
									where pres.countyname = coun.countyname AND pres.statecode = coun.statecode AND coun.year = 2012))

select v2008.countyname AS countyname, v2008.statecode AS statecode
from v2008

INTERSECT

select v2012.countyname AS countyname, v2012.statecode AS statecode
from v2012

order by countyname, statecode;

"""


### 12. The anti-join of two relations A and B over some predicate P is defined to be the all of the tuples
### A_i of relation A where there is no matching B_j in B such that (A_i, B_j) satisfies P.
### When exploring unknown datasets the anti-join can be useful to identify anomalies or inconsistencies in  
### names and identifiers across tables in the dataset.
### Find the anti-join of `counties` with `pres_county_returns` to identify counties from the `counties` table
### where no votes have been recorded.
### Output columns: statecode, name
### Order by: statecode, name
queries[12] = """

select statecode, name
from counties

where NOT EXISTS
(select statecode, countyname 
	from pres_county_returns 
	where candidatevotes IS NULL)

order by statecode, name;

"""

### 13. Find all presidential candidates listed in pres_county_returns who also ran for senator.
### HINT: Use "intersect" to simplify the query
###
### Every candidate should be reported only once. 
###
### Output columns: candidatename
### Order by: candidatename
queries[13] = """

select distinct(candidatename) AS candidatename 
from pres_county_returns
where candidatename != 'Other'
INTERSECT

select distinct(candidatename) AS candidatename
from sen_state_returns
where candidatename != 'Other'
order by candidatename;

"""

### 14. Create a table listing the months and the number of states that were admitted to the union (admitted_to_union field) in that month.
### Use 'extract' for operating on dates, and the ability to create a small inline table in SQL. For example, try:
###         select * from (values(1, 'Jan'), (2, 'Feb')) as x;
###
### Output columns: month_no, monthname, num_states_admitted
### month should take values: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
### Order by: month_no
queries[14] = """

select EXTRACT(MONTH FROM admitted_to_union) AS month_no,
		month.name AS monthname, 
		COUNT(admitted_to_union) AS num_states_admitted
from states,

(values(1, 'Jan'), (2, 'Feb'), (3, 'Mar'), (4, 'Apr'), (5, 'May'), (6, 'Jun'),
 						(7, 'Jul'), (8, 'Aug'), (9, 'Sep'), (10, 'Oct'), (11, 'Nov'), (12, 'Dec')) AS month(num,name)

where EXTRACT(MONTH FROM admitted_to_union) = month.num

group by month_no, monthname

order by month_no;

"""


### 15. Create a view pres_state_votes with schema (year, statecode, candidatename, partyname, candidatevotes) where we maintain aggregated counts by statecode (i.e.,
### candidatevotes in this view would be the total votes for each state, including states with statecode 'NA'). XX
queries[15] = """

create view pres_state_votes as
select year, statecode, candidatename, partyname, SUM(candidatevotes) AS candiadatevotes

from pres_county_returns

group by year, statecode, candidatename, partyname;

"""

### 16. Use a single ALTER TABLE statement to add (name, statecode) as primary key to counties, and to add CHECKs that neither of the two populations are less than zero.
### Name the two CHECK constraints nonzero2010 and nonzero1950. XX
queries[16] = """

Alter table counties
Add CONSTRAINT const_primary PRIMARY KEY(name, statecode),
ADD CONSTRAINT nonzero2010 CHECK (population_2010 >= 0),
ADD CONSTRAINT nonzero1950 CHECK (population_1950 >= 0);

"""

### 17. Create a list of percentage each presidential candidate won in each state, in each year, and
### show only the top 10 (among all year and state) in descending order. "percentvote" should be a float
### with one digit to the right of the decimal point.
### Output columns: year, statecode, candidatename, percentvote
### Order by: percentvote desc, year asc, candidatename asc, limit to 10 lines
queries[17] = """

with table1 as (select year, statecode, SUM(candidatevotes) AS totalvotes
				from pres_county_returns
				group by year, statecode),

table2 as (select year, statecode, candidatename, SUM(candidatevotes) AS votes
				from pres_county_returns
				group by year, statecode, candidatename)

select table1.year AS year, 
		table1.statecode AS statecode, 
		table2.candidatename, 
		table2.votes,	
		table1.totalvotes,
		ROUND(((table2.votes::numeric/table1.totalvotes::numeric)*100),1) AS percentvote
from table1

join table2 on (table1.year = table2.year AND
				table1.statecode = table2.statecode)							

where (table1.totalvotes > 0)

order by percentvote desc, table1.year asc, candidatename asc

limit 10;

"""

### 18. Create a list of percentage of people who turned out to vote for each state in the presidential election of 2000
### in descending order. "percentturnout" should be a float with one digit to the right of the decimal point.
### Output columns: statecode, percentturnout
### Order by: percentageturnout desc;
queries[18] = """

with table1 as (select statecode, SUM(candidatevotes) as votes
				from pres_county_returns
				where year = 2000
				group by statecode),

table2 as (select statecode, population_2000
			from states)

select table1.statecode, 
		ROUND(((table1.votes::numeric/table2.population_2000::numeric)*100), 1) AS percentturnout
from table1

join table2 on (table1.statecode = table2.statecode)

where (table2.population_2000 > 0)

order by percentturnout desc;

"""
