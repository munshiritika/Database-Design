# EXPLANATION: The given left-join query fails because ...
# The given left-join query fails because the output still prints the data of all those users not only for William but we get all the users whose name is not William.
# The on condition is where is join based on the same columns on both the columns. 
# Instead of checking for William user within the on clause, we can check outside after the join.
# Also, we have to make changes to the count(*), because this counts aggregately and we have to count only if they flew where both the counts have different roles.
queryWilliam = """

select c.customerid, c.name, count(flightid)
from customers c 
left outer join flewon f on (c.customerid = f.customerid)
where c.name like 'William%'
group by c.customerid, c.name
order by c.customerid;

"""



# NOTE:  This trigger is both INCORRECT and INCOMPLETE. You need to find and fix the bugs, and ensure
# that it will correctly update NumberOfFlightsTaken on both insertions and deletions from "flewon".
queryTrigger = """

CREATE OR REPLACE FUNCTION updateStatusCount() RETURNS trigger AS $updateStatus$
		DECLARE
			old_flight_count integer;
		BEGIN
            IF (TG_OP = 'INSERT') THEN
                IF EXISTS (SELECT customerid FROM NumberOfFlightsTaken WHERE customerid = NEW.customerid) THEN

                    UPDATE NumberOfFlightsTaken
                    SET numflights = (numflights + 1)
                    WHERE customerid = NEW.customerid;
                ELSE
                   
                    INSERT INTO NumberOfFlightsTaken 
                    values (NEW.customerid, (select c.name from customers c where c.customerid = NEW.customerid) , 1);
                   
                END IF;
            ELSE
                SELECT numflights INTO old_flight_count FROM NumberOfFlightsTaken WHERE customerid = OLD.customerid;

                IF (old_flight_count = 1) THEN 
                    Delete from NumberOfFlightsTaken;                
                ELSE            
                    Update NumberOfFlightsTaken
                    set numflights = old_flight_count - 1
                    where customerid = OLD.customerid;
                    
                END IF;               
                  
            END IF;
        RETURN NULL;
        
		END;
$updateStatus$ LANGUAGE plpgsql;

CREATE TRIGGER update_num_status AFTER 
INSERT OR DELETE ON flewon
FOR EACH ROW EXECUTE PROCEDURE updateStatusCount();
END;
"""
